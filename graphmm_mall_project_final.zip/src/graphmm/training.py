from __future__ import annotations
from typing import List, Optional, Tuple
import os, random
import torch
from tqdm import tqdm

from graphmm.datasets.trajectory_provider import pad_batch, PADDING_ID, Sample, build_transition_graph
from graphmm.models.graphmm_corrector import GraphMMCorrector, decode_argmax
from graphmm.utils.graph import token_seq_accuracy, path_feasibility_rate, build_adj_list, k_hop_neighbors

def train_loop(
    model: GraphMMCorrector,
    graph_batch,
    train_samples: List[Sample],
    valid_samples: List[Sample],
    epochs: int,
    batch_size: int,
    lr: float,
    device: str,
    run_dir: str,
    k_hop: int,
    top_r_train: int,
    top_r_decode: int,
    use_crf: bool,
):
    os.makedirs(run_dir, exist_ok=True)
    model = model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    node_num_feat = graph_batch.node_num_feat.to(device)
    floor_id = graph_batch.floor_id.to(device)
    edge_index = graph_batch.edge_index.to(device)
    edge_attr = graph_batch.edge_attr.to(device)

    road_adj_list = build_adj_list(graph_batch.num_nodes, edge_index)
    allowed_prev = k_hop_neighbors(road_adj_list, k=k_hop) if use_crf else None

    def build_traj_graph_from_samples(samples: List[Sample]) -> Tuple[torch.Tensor, torch.Tensor]:
        # edges with counts
        ecount = build_transition_graph([s.pred for s in samples], directed=True, min_count=1)
        if not ecount:
            # dummy self-loop
            idx = torch.arange(graph_batch.num_nodes, device=device)
            edge_idx = torch.stack([idx, idx], dim=0)
            w = torch.ones(idx.numel(), device=device)
            return edge_idx, w
        src = torch.tensor([u for (u,v,c) in ecount], dtype=torch.long, device=device)
        dst = torch.tensor([v for (u,v,c) in ecount], dtype=torch.long, device=device)
        w = torch.tensor([float(c) for (u,v,c) in ecount], dtype=torch.float32, device=device)
        # normalize weights by mean
        w = w / w.mean().clamp(min=1e-6)
        edge_idx = torch.stack([src,dst], dim=0)
        return edge_idx, w

    def run_eval(samples: List[Sample]):
        model.eval()
        all_p = []
        all_g = []
        with torch.no_grad():
            # traj graph 用训练集统计（保持一致）
            traj_edge_index, traj_edge_weight = build_traj_graph_from_samples(train_samples)

            for i in range(0, len(samples), batch_size):
                batch = samples[i:i + batch_size]
                pred_seqs = [s.pred for s in batch]
                true_seqs = [s.true for s in batch]

                pred_pad, lengths = pad_batch(pred_seqs, pad_id=PADDING_ID)
                pred_pad = pred_pad.to(device)
                lengths = lengths.to(device)

                # ✅ eval阶段：不要teacher forcing，模拟真实推理
                unary_logits, H_R = model.forward_unary(
                    pred_pad, lengths,
                    node_num_feat=node_num_feat,
                    floor_id=floor_id,
                    edge_index=edge_index,
                    edge_attr=edge_attr,
                    traj_edge_index=traj_edge_index,
                    traj_edge_weight=traj_edge_weight,
                    teacher_forcing=None
                )

                if use_crf:
                    out = []
                    for bi in range(len(batch)):
                        L = int(lengths[bi].item())
                        unary_i = unary_logits[bi, :L, :]
                        path = model.crf.viterbi_one(unary_i, H_R, allowed_prev, top_r=top_r_decode)
                        out.append(path)
                else:
                    out = decode_argmax(unary_logits, lengths)

                all_p.extend(out)
                all_g.extend(true_seqs)

        tok, seq = token_seq_accuracy(all_p, all_g)
        feas = path_feasibility_rate(all_p, road_adj_list, k_hop=max(1, k_hop))
        return tok, seq, feas

    best = -1.0
    for ep in range(1, epochs+1):
        model.train()
        random.shuffle(train_samples)
        total_loss=0.0; total_cnt=0

        traj_edge_index, traj_edge_weight = build_traj_graph_from_samples(train_samples)

        for i in tqdm(range(0, len(train_samples), batch_size), desc=f"epoch {ep}"):
            batch = train_samples[i:i+batch_size]
            pred_seqs=[s.pred for s in batch]
            true_seqs=[s.true for s in batch]
            pred_pad, lengths = pad_batch(pred_seqs, pad_id=PADDING_ID)
            true_pad, _ = pad_batch(true_seqs, pad_id=PADDING_ID)

            pred_pad = pred_pad.to(device); true_pad = true_pad.to(device); lengths = lengths.to(device)

            # ---- Scheduled Sampling (TRAIN) ----
            ss_start, ss_end = 1.0, 0.2  # 你也可以从config读
            if epochs <= 1:
                p_true = ss_end
            else:
                p_true = ss_start + (ss_end - ss_start) * (ep - 1) / (epochs - 1)
            p_true = float(max(0.0, min(1.0, p_true)))

            valid_mask = (true_pad != PADDING_ID)  # [B,L]
            rand = torch.rand(true_pad.shape, device=device)
            use_true = (rand < p_true) & valid_mask  # True->用true, False->用pred

            tf_inp = torch.where(use_true, true_pad, pred_pad)  # [B,L]

            unary_logits, H_R = model.forward_unary(
                pred_pad, lengths,
                node_num_feat=node_num_feat,
                floor_id=floor_id,
                edge_index=edge_index,
                edge_attr=edge_attr,
                traj_edge_index=traj_edge_index,
                traj_edge_weight=traj_edge_weight,
                teacher_forcing=tf_inp
            )

            if use_crf:
                loss = torch.tensor(0.0, device=device)
                for bi in range(len(batch)):
                    L = int(lengths[bi].item())
                    unary_i = unary_logits[bi,:L,:]
                    gold_i = true_seqs[bi]
                    loss = loss + model.crf.nll_one(unary_i, gold_i, H_R, allowed_prev, top_r=top_r_train, train_mode=True)
                loss = loss / max(len(batch),1)
            else:
                B, Lm, N = unary_logits.shape
                loss = torch.nn.functional.cross_entropy(unary_logits.view(B*Lm, N), true_pad.view(B*Lm), ignore_index=PADDING_ID)

            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

            total_loss += float(loss.item()) * len(batch)
            total_cnt += len(batch)

        train_loss = total_loss / max(total_cnt,1)
        val_tok, val_seq, val_feas = run_eval(valid_samples) if valid_samples else (0.0,0.0,0.0)

        print(f"[epoch {ep:02d}] loss={train_loss:.4f} val_tok={val_tok:.3f} val_seq={val_seq:.3f} feas@k={val_feas:.3f}")

        score = val_tok + 0.1 * val_feas
        if score > best:
            best = score
            torch.save(
                {"model": model.state_dict(), "epoch": ep, "val_tok": val_tok, "val_seq": val_seq, "feas": val_feas},
                os.path.join(run_dir, "checkpoint.pt")
            )
