from __future__ import annotations
from typing import Optional, Tuple, List
import torch
import torch.nn as nn
import torch.nn.functional as F

from graphmm.models.layers import GINEdgeLayer, DotAttention, WeightedGCNLayer
from graphmm.models.node_encoder import NodeFeatureEncoder
from graphmm.models.crf import GraphCRF
from graphmm.datasets.trajectory_provider import PADDING_ID

class GraphMMCorrector(nn.Module):
    def __init__(
        self,
        num_nodes: int,
        num_floors: int,
        road_dim: int = 64,
        gin_layers: int = 2,
        gin_mlp_hidden: int = 128,
        edge_feat_dim: int = 5,
        dropout: float = 0.1,
        temperature: float = 12.0,
        node_num_dim: int = 5,
        floor_emb_dim: int = 8,
        traj_gcn_layers: int = 1,
        use_crf: bool = True,
        unreachable_penalty: float = -1e4,
    ):
        super().__init__()
        self.num_nodes = num_nodes
        self.road_dim = road_dim
        self.temperature = temperature
        self.use_crf = use_crf

        self.node_encoder = NodeFeatureEncoder(num_floors, node_num_dim, floor_emb_dim, road_dim)

        self.edge_proj = nn.Sequential(
            nn.Linear(edge_feat_dim, road_dim),
            nn.ReLU(),
            nn.Linear(road_dim, road_dim),
        )
        self.gine = nn.ModuleList([
            GINEdgeLayer(road_dim, road_dim, gin_mlp_hidden, dropout) for _ in range(gin_layers)
        ])

        # trajectory correlation encoder (GCN on transition graph)
        self.traj_gcn = nn.ModuleList([WeightedGCNLayer(road_dim) for _ in range(traj_gcn_layers)])

        # Seq2Seq
        self.encoder = nn.GRU(road_dim, road_dim, batch_first=True, bidirectional=True)
        self.enc_proj = nn.Linear(road_dim*2, road_dim)

        self.decoder = nn.GRU(road_dim, road_dim, batch_first=True)
        self.attn = DotAttention()
        self.dec_out = nn.Linear(road_dim*2, road_dim)

        self.crf = GraphCRF(road_dim, unreachable_penalty=unreachable_penalty) if use_crf else None

    def compute_H_R(self, node_num_feat, floor_id, edge_index, edge_attr):
        H = self.node_encoder(node_num_feat, floor_id)
        Eemb = self.edge_proj(edge_attr)
        for layer in self.gine:
            H = F.relu(layer(H, edge_index, Eemb))
        return F.normalize(H, p=2, dim=-1)

    def enhance_with_traj_graph(self, H_R: torch.Tensor, traj_edge_index: Optional[torch.Tensor], traj_edge_weight: Optional[torch.Tensor]):
        if traj_edge_index is None or traj_edge_weight is None or len(self.traj_gcn) == 0:
            return H_R
        H = H_R
        for gcn in self.traj_gcn:
            H = F.relu(gcn(H, traj_edge_index, traj_edge_weight))
        return F.normalize(H, p=2, dim=-1)

    def hidden_similarity(self, Z, H_R):
        return torch.einsum("bld,nd->bln", Z, H_R) * self.temperature

    def forward_unary(
            self,
            pred_seq: torch.Tensor,
            lengths: torch.Tensor,
            node_num_feat: torch.Tensor,
            floor_id: torch.Tensor,
            edge_index: torch.Tensor,
            edge_attr: torch.Tensor,
            traj_edge_index: Optional[torch.Tensor] = None,
            traj_edge_weight: Optional[torch.Tensor] = None,
            teacher_forcing: Optional[torch.Tensor] = None,
    ):
        """
        Returns:
          unary_logits: [B,L,N]
          H_R: [N,d]
        NOTE:
          - training: pass teacher_forcing=true_pad (standard teacher forcing)
          - inference: teacher_forcing=None -> **autoregressive decoding**
        """
        device = pred_seq.device
        B, Lmax = pred_seq.shape

        # 1) road embeddings
        H_R = self.compute_H_R(node_num_feat, floor_id, edge_index, edge_attr)
        H_R = self.enhance_with_traj_graph(H_R, traj_edge_index, traj_edge_weight)

        # 2) encoder input from pred ids
        pred_safe = pred_seq.clone()
        pred_safe[pred_safe == PADDING_ID] = 0
        enc_inp = H_R[pred_safe]  # [B,L,d]

        packed = nn.utils.rnn.pack_padded_sequence(enc_inp, lengths.cpu(), batch_first=True, enforce_sorted=False)
        enc_out_packed, _ = self.encoder(packed)
        enc_out, _ = nn.utils.rnn.pad_packed_sequence(enc_out_packed, batch_first=True, total_length=Lmax)
        enc_out = F.normalize(self.enc_proj(enc_out), p=2, dim=-1)

        mask = (pred_seq != PADDING_ID)  # [B,L]
        enc_mean = (enc_out * mask.unsqueeze(-1)).sum(1) / mask.sum(1).clamp(min=1).unsqueeze(-1)
        dec_h = enc_mean.unsqueeze(0)  # [1,B,d]

        # 3) decoding (teacher forcing OR autoregressive)
        zero = torch.zeros(B, self.road_dim, device=device)
        prev_emb = zero  # step0 input

        if teacher_forcing is not None:
            # -------- training: teacher forcing --------
            tf = teacher_forcing.clone()
            tf[tf == PADDING_ID] = 0

            dec_inputs = []
            for t in range(Lmax):
                dec_inputs.append(prev_emb.unsqueeze(1))
                prev_emb = H_R[tf[:, t]]  # next input is gold embedding

            dec_inp = torch.cat(dec_inputs, dim=1)  # [B,L,d]
            dec_out, _ = self.decoder(dec_inp, dec_h)  # [B,L,d]

        else:
            # -------- inference: autoregressive --------
            dec_out_steps = []
            cur_h = dec_h  # [1,B,d]

            for t in range(Lmax):
                # one-step GRU
                step_inp = prev_emb.unsqueeze(1)  # [B,1,d]
                step_out, cur_h = self.decoder(step_inp, cur_h)  # step_out: [B,1,d]
                ht = step_out[:, 0, :]  # [B,d]
                dec_out_steps.append(ht.unsqueeze(1))

                # attention + get logits for this step (no CRF here, just for next input)
                ctx = self.attn(ht, enc_out, enc_out, mask=mask)  # [B,d]
                zt = F.normalize(self.dec_out(torch.cat([ht, ctx], dim=-1)), p=2, dim=-1)  # [B,d]
                step_logits = torch.einsum("bd,nd->bn", zt, H_R) * self.temperature  # [B,N]

                # update prev_emb with predicted id (greedy) for next step
                pred_id = torch.argmax(step_logits, dim=-1)  # [B]
                prev_emb = H_R[pred_id]

            dec_out = torch.cat(dec_out_steps, dim=1)  # [B,L,d]

        # 4) attention for full sequence output (teacher forcing path)
        # for autoregressive path we already used attention per step to update prev_emb,
        # but we still compute final Z consistently to output unary logits.
        ctx_list = []
        for t in range(Lmax):
            q = dec_out[:, t, :]
            ctx = self.attn(q, enc_out, enc_out, mask=mask)
            ctx_list.append(ctx.unsqueeze(1))
        ctx_all = torch.cat(ctx_list, dim=1)  # [B,L,d]

        Z = F.normalize(self.dec_out(torch.cat([dec_out, ctx_all], dim=-1)), p=2, dim=-1)
        unary_logits = self.hidden_similarity(Z, H_R)  # [B,L,N]
        return unary_logits, H_R

@torch.no_grad()
def decode_argmax(unary_logits, lengths):
    pred = torch.argmax(unary_logits, dim=-1)
    return [pred[i,:int(lengths[i].item())].tolist() for i in range(pred.size(0))]
